package it.polito.ezshop.acceptanceTests;


public class TestEZShop {
    
    
}
